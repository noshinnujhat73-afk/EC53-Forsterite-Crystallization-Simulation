from __future__ import annotations
import json
from pathlib import Path
import pandas as pd


def load_temperature_history(path):
    path = Path(path)
    df = pd.read_csv(path)
    required = {"time_s", "temperature_K"}
    if not required.issubset(df.columns):
        raise ValueError("Temperature CSV must contain time_s,temperature_K.")
    if len(df) < 2:
        raise ValueError("Temperature history must contain at least two rows.")
    if df["temperature_K"].isna().any() or df["time_s"].isna().any():
        raise ValueError("Temperature history contains missing values.")
    if (df["temperature_K"] <= 0).any():
        raise ValueError("All temperatures must be > 0 K.")
    if (df["time_s"].diff().dropna() <= 0).any():
        raise ValueError("time_s must be strictly increasing.")
    return df


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2), encoding="utf-8")
