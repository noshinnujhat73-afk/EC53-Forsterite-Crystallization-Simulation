from pathlib import Path
import matplotlib.pyplot as plt


def make_figures(result, outdir):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    t_hr = result["time_s"] / 3600.0
    T = result["temperature_K"]
    X = result["crystalline_fraction"]
    k = result["rate_s_inv"]

    plt.figure()
    plt.plot(t_hr, T)
    plt.xlabel("Time (h)")
    plt.ylabel("Temperature (K)")
    plt.tight_layout()
    plt.savefig(outdir / "temperature_vs_time.png", dpi=220)
    plt.close()

    plt.figure()
    plt.semilogy(t_hr, k)
    plt.xlabel("Time (h)")
    plt.ylabel("Crystallization rate k (s$^{-1}$)")
    plt.tight_layout()
    plt.savefig(outdir / "rate_vs_time.png", dpi=220)
    plt.close()

    plt.figure()
    plt.plot(t_hr, 100.0 * X)
    plt.xlabel("Time (h)")
    plt.ylabel("Crystalline fraction (%)")
    plt.tight_layout()
    plt.savefig(outdir / "crystallinity_vs_time.png", dpi=220)
    plt.close()
