from pathlib import Path
import numpy as np
import pandas as pd

from .io import load_temperature_history, write_json
from .model import integrate_crystallinity, NU_S_INV, EA_OVER_K_K
from .plotting import make_figures

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input" / "ec53_temperature_history.csv"
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"


def main():
    if INPUT.stat().st_size <= 25:
        raise RuntimeError(
            "No source/model-derived EC 53 temperature history is installed. "
            "Populate input/ec53_temperature_history.csv and document its provenance "
            "in docs/TEMPERATURE_PROVENANCE.md before running a scientific simulation."
        )

    df = load_temperature_history(INPUT)
    result = integrate_crystallinity(
        df.time_s.to_numpy(),
        df.temperature_K.to_numpy(),
        x0=0.0,
        nu_s_inv=NU_S_INV,
        ea_over_k_K=EA_OVER_K_K,
    )

    RESULTS.mkdir(exist_ok=True)
    out = pd.DataFrame(result)
    out["crystallinity_percent"] = 100.0 * out["crystalline_fraction"]
    out.to_csv(RESULTS / "baseline_timeseries.csv", index=False)

    err = np.max(np.abs(
        result["crystalline_fraction"] -
        result["crystalline_fraction_quadrature"]
    ))

    summary = {
        "nu_s_inv": NU_S_INV,
        "Ea_over_k_K": EA_OVER_K_K,
        "initial_crystalline_fraction": 0.0,
        "final_crystalline_fraction": float(result["crystalline_fraction"][-1]),
        "final_crystallinity_percent": float(100.0 * result["crystalline_fraction"][-1]),
        "max_numerical_vs_quadrature_error": float(err),
        "temperature_input": str(INPUT.relative_to(ROOT)),
        "status": "SOURCE/MODEL TEMPERATURE REQUIRED; NO FABRICATED TEMPERATURE USED"
    }
    write_json(RESULTS / "baseline_summary.json", summary)
    pd.DataFrame({
        "max_abs_error": [err]
    }).to_csv(RESULTS / "validation.csv", index=False)
    make_figures(result, FIGURES)

    print("Simulation completed.")
    print(f"Final crystallinity: {summary['final_crystallinity_percent']:.8f}%")
    print(f"Numerical-vs-quadrature max error: {err:.3e}")


if __name__ == "__main__":
    main()
