from __future__ import annotations

import numpy as np
from scipy.integrate import quad, solve_ivp

NU_S_INV = 2.0e13
EA_OVER_K_K = 39100.0


def arrhenius_rate(T_K, nu_s_inv=NU_S_INV, ea_over_k_K=EA_OVER_K_K):
    T = np.asarray(T_K, dtype=float)
    if np.any(T <= 0):
        raise ValueError("Temperature must be > 0 K.")
    return nu_s_inv * np.exp(-ea_over_k_K / T)


def _validate_history(time_s, temperature_K):
    t = np.asarray(time_s, dtype=float)
    T = np.asarray(temperature_K, dtype=float)
    if t.ndim != 1 or T.ndim != 1 or len(t) != len(T):
        raise ValueError("time_s and temperature_K must be 1-D arrays of equal length.")
    if len(t) < 2 or np.any(np.diff(t) <= 0):
        raise ValueError("time_s must be strictly increasing.")
    if np.any(T <= 0):
        raise ValueError("Temperature must be > 0 K.")
    return t, T


def integrate_crystallinity(time_s, temperature_K, x0=0.0,
                            nu_s_inv=NU_S_INV,
                            ea_over_k_K=EA_OVER_K_K):
    """Solve dX/dt = k(T)(1-X) and independently check it by adaptive quadrature.

    The temperature history is treated as piecewise-linear between supplied samples.
    RK45 and scipy.integrate.quad therefore solve/check the same mathematical input,
    while using independent numerical algorithms.
    """
    t, T = _validate_history(time_s, temperature_K)
    if not (0.0 <= x0 <= 1.0):
        raise ValueError("x0 must be between 0 and 1.")

    def temp_interp(ti):
        return float(np.interp(ti, t, T))

    def rate_at(ti):
        return float(arrhenius_rate(temp_interp(ti), nu_s_inv, ea_over_k_K))

    def rhs(ti, y):
        return [rate_at(ti) * (1.0 - y[0])]

    sol = solve_ivp(
        rhs, (t[0], t[-1]), [x0], t_eval=t, method="RK45",
        rtol=1e-10, atol=1e-12
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    x_num = np.clip(sol.y[0], 0.0, 1.0)

    # Independent adaptive quadrature of the analytic solution:
    # X(t) = 1 - (1-X0) exp(-integral k(t) dt).
    cumulative_integral = np.zeros_like(t)
    for i in range(1, len(t)):
        cumulative_integral[i] = quad(
            rate_at, float(t[i - 1]), float(t[i]),
            epsabs=1e-14, epsrel=1e-10, limit=100
        )[0] + cumulative_integral[i - 1]
    x_quad = 1.0 - (1.0 - x0) * np.exp(-cumulative_integral)
    x_quad = np.clip(x_quad, 0.0, 1.0)

    return {
        "time_s": t,
        "temperature_K": T,
        "rate_s_inv": arrhenius_rate(T, nu_s_inv, ea_over_k_K),
        "crystalline_fraction": x_num,
        "crystalline_fraction_quadrature": x_quad,
    }
