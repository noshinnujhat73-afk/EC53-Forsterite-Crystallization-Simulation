from __future__ import annotations

import numpy as np
from .model import integrate_crystallinity, NU_S_INV, EA_OVER_K_K


def repeat_temperature_history(time_s, temperature_K, cycle_s, n_cycles, gap_temperature_K=None):
    """Repeat a source/model temperature history for multiple cycles.

    The input history is one cycle. Each repetition is shifted by cycle_s.
    If cycle_s exceeds the cycle duration, the remaining interval is held at the
    first temperature unless gap_temperature_K is supplied.
    """
    if n_cycles < 1 or int(n_cycles) != n_cycles:
        raise ValueError("n_cycles must be a positive integer.")
    t = np.asarray(time_s, dtype=float)
    T = np.asarray(temperature_K, dtype=float)
    if cycle_s <= 0:
        raise ValueError("cycle_s must be > 0.")
    duration = t[-1] - t[0]
    pieces_t, pieces_T = [], []
    gap_T = float(T[0] if gap_temperature_K is None else gap_temperature_K)
    for i in range(int(n_cycles)):
        shift = i * cycle_s - t[0]
        ti = t + shift
        pieces_t.append(ti)
        pieces_T.append(T)
        if i < int(n_cycles) - 1 and cycle_s > duration:
            gap_t0 = ti[-1]
            gap_t1 = (i + 1) * cycle_s - t[0]
            if gap_t1 > gap_t0:
                pieces_t.append(np.array([gap_t0, gap_t1]))
                pieces_T.append(np.array([T[-1], gap_T]))
    out_t, out_T = [], []
    for ti, Ti in zip(pieces_t, pieces_T):
        if out_t and ti[0] <= out_t[-1][-1]:
            ti, Ti = ti[1:], Ti[1:]
        if len(ti):
            out_t.append(ti)
            out_T.append(Ti)
    return np.concatenate(out_t), np.concatenate(out_T)


def simulate_multiburst(time_s, temperature_K, cycle_s, n_cycles, x0=0.0,
                         nu_s_inv=NU_S_INV, ea_over_k_K=EA_OVER_K_K,
                         gap_temperature_K=None):
    t, T = repeat_temperature_history(time_s, temperature_K, cycle_s, n_cycles,
                                      gap_temperature_K=gap_temperature_K)
    return integrate_crystallinity(t, T, x0=x0, nu_s_inv=nu_s_inv,
                                   ea_over_k_K=ea_over_k_K)
