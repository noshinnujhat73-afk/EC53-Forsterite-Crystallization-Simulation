import numpy as np
from src.model import integrate_crystallinity
from src.multiburst import simulate_multiburst


def test_constant_temperature_matches_analytic_solution():
    t = np.linspace(0, 3600, 25)
    T = np.full_like(t, 1000.0)
    x0 = 0.1
    nu = 2e13
    ea = 39100.0
    r = integrate_crystallinity(t, T, x0=x0, nu_s_inv=nu, ea_over_k_K=ea)
    k = nu * np.exp(-ea / 1000.0)
    expected = 1 - (1 - x0) * np.exp(-k * (t - t[0]))
    assert np.max(np.abs(r["crystalline_fraction"] - expected)) < 1e-7
    assert np.max(np.abs(r["crystalline_fraction"] - r["crystalline_fraction_quadrature"])) < 1e-7


def test_temperature_validation():
    t = np.array([0, 1, 2])
    T = np.array([300, 0, 500])
    try:
        integrate_crystallinity(t, T)
    except ValueError:
        pass
    else:
        raise AssertionError("Non-positive temperature should fail")


def test_multiburst_is_monotonic_and_extends_duration():
    t = np.linspace(0, 100, 11)
    T = np.full_like(t, 1000.0)
    r = simulate_multiburst(t, T, cycle_s=150, n_cycles=3)
    assert r["time_s"][-1] > t[-1]
    assert np.all(np.diff(r["crystalline_fraction"]) >= -1e-12)
