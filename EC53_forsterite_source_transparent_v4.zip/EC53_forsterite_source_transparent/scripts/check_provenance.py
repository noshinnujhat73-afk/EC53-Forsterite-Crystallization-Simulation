from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parents[1]
temperature = ROOT / "input" / "ec53_temperature_history.csv"

if temperature.read_text().strip() == "time_s,temperature_K":
    raise SystemExit(
        "STOP: no EC 53 temperature history is installed. "
        "Add a source-derived temperature file and document provenance."
    )

print("Temperature input exists. Verify docs/TEMPERATURE_PROVENANCE.md before publication.")
