# Temperature input

This file is intentionally a template.

Do not fill it with 950 K / 12 h / sin^2 values and call them EC 53 observations.

A valid scientific input should come from:
1. a published EC 53 physical/radiative-transfer model; or
2. a reproducible RADMC-3D model whose parameters are documented; or
3. a temperature history derived from public observations using a documented physical model.

Record the exact provenance in `docs/TEMPERATURE_PROVENANCE.md`.
