# Assumption / Provenance Ledger

| Item | Value/status | Classification |
|---|---|---|
| EC 53 cycle | ~530 d | SOURCE: Lee et al. 2020 |
| Burst rise | ~0.12 yr | SOURCE: Lee et al. 2020 |
| Decay e-folding | ~0.74 yr | SOURCE: Lee et al. 2020 |
| Outburst/quiescent luminosity | ~3.3 | SOURCE: Baek et al. 2020 |
| Peak accretion rate | ~8e-6 Msun/yr | SOURCE: Lee et al. 2020 |
| Forsterite/enstatite burst emission | observed | SOURCE: Lee et al. 2026 |
| MIRI/NIRCam data | public via MAST | SOURCE: Lee et al. 2026 |
| ALMA project | 2022.1.00800.S | SOURCE: Lee et al. 2026 |
| nu | 2e13 s^-1 | LITERATURE KINETICS |
| Ea/kB | 39100 K | LITERATURE KINETICS |
| dX/dt = k(T)(1-X) | model equation | MODEL FORMULATION |
| T(t) | must be supplied | REQUIRED EXTERNAL MODEL INPUT |
| 950 K peak | not used | EXPLICITLY AVOIDED |
| 12 h duration | not used | EXPLICITLY AVOIDED |
| sin^2 T(t) | not used | EXPLICITLY AVOIDED |
| Sensitivity ranges | not fixed | TO BE DEFINED AFTER T MODEL |
