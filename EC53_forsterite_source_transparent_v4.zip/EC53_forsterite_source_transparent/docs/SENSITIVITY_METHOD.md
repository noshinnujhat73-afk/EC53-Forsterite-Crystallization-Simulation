# Sensitivity Analysis

The application performs one-factor-at-a-time computational sensitivity tests around the selected baseline.

Default test factors:
- Temperature: 0.90, 0.95, 1.00, 1.05, 1.10
- `nu`: 0.5, 0.8, 1.0, 1.2, 2.0
- `Ea/kB`: 0.90, 0.95, 1.00, 1.05, 1.10

These ranges are **not measurements or uncertainty intervals**. They are controlled numerical experiments used to show how strongly the model responds to each parameter.
