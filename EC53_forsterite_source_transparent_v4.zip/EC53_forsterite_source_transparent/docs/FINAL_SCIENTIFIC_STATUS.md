# Final Scientific Status — Version 4

## Status
This package is a **source-grounded research simulation**, not a claim that all code was copied from published work.

### Source-derived / externally established
- EC 53 observational constraints and burst context: Lee et al. (2020, 2026).
- EC 53 radiative-transfer/model context: Baek et al. (2020) and Lee et al. (2026).
- Forsterite crystallization kinetics: Fabian et al. (2000) and Jang et al. (2024).
- Public scientific software links: EPISODE, RADMC-3D, optool, emcee and JWST pipeline, as documented in `docs/SOURCE_CODE_MAP.md`.

### Project-specific implementation
- `src/model.py`: integration/adapter implementation using published kinetic equations and literature parameters.
- `src/multiburst.py`: multi-burst orchestration built for this project.
- `app.py`: Streamlit interface and visualization layer.
- Sensitivity-analysis orchestration and result export.

### Numerical validation
The RK45 solution is now checked against an **independent adaptive `scipy.integrate.quad` calculation** of the integrated Arrhenius rate using the same piecewise-linear temperature history. This replaces the previous trapezoidal-grid check.

### Important limitation
`input/ec53_temperature_history.csv` remains intentionally empty. No fabricated 950 K / 12 h / sin² history is included or labelled as EC 53 data. A publication-quality EC 53 result requires a defensible source/model-derived `T(t)` or `T(r,t)` input.

### Multi-burst status
A reusable multi-burst module is included. Its cycle period and gap temperature are **model inputs**, not observations unless independently sourced and documented.
