# Reproducibility

## Upstream repositories
If internet access is available, the following public repositories can be obtained directly from their authors/maintainers:

- https://github.com/SNUSF/EPISODE
- https://github.com/JY-Kim8502/JKAS_IRS_Continuum_fitting_with_Slicate
- https://github.com/dullemond/radmc3d-2.0
- https://github.com/cdominik/optool
- https://github.com/dfm/emcee
- https://github.com/spacetelescope/jwst

The EC 53 Nature paper itself lists these repositories/software in its Code availability section.

## Why the temperature CSV is empty
The project must not turn a hypothetical temperature curve into an alleged EC 53 observation. A source/model-derived EC 53 temperature history must be supplied before producing an EC 53-specific crystallization result.
