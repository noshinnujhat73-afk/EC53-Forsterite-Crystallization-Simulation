# Numerical Validation Method

The crystallization equation is

`dX/dt = k(T)(1-X)`

with

`k(T) = nu * exp[-(Ea/kB)/T]`.

For a supplied piecewise-linear temperature history, the exact integral form is

`X(t) = 1 - (1-X0) exp[-integral(k(T(t)) dt)]`.

The implementation calculates this in two independent ways:

1. RK45 solves the ODE directly.
2. `scipy.integrate.quad` adaptively integrates `k(T(t))` over each interval and uses the analytic integral form.

The maximum absolute difference is reported by the application. This is a numerical consistency check, not observational validation of EC 53.
