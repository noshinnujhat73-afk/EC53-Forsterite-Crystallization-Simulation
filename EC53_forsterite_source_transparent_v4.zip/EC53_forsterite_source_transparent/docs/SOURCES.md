# Primary sources

## 1. Lee et al. 2026 — Nature
Lee, J.-E. et al. 2026, "Accretion bursts crystallize silicates in a planet-forming disk",
Nature 649, 853-858.
DOI: 10.1038/s41586-025-09939-3
https://www.nature.com/articles/s41586-025-09939-3

Used for:
- EC 53 burst-phase forsterite/enstatite detection;
- public JWST MIRI/NIRCam data availability;
- ALMA project 2022.1.00800.S;
- public code repositories listed by the authors.

## 2. Lee et al. 2020
Lee, Y.-H. et al. 2020, "Young Faithful: The Eruptions of EC 53 as it Cycles through
Filling and Draining the Inner Disk", arXiv:2009.05268.
https://arxiv.org/abs/2009.05268

Used for:
- ~530 day cycle;
- ~0.12 yr rise;
- ~0.74 yr decay e-folding;
- peak accretion-rate constraint.

## 3. Baek et al. 2020
Baek, G. et al. 2020, "Radiative Transfer modeling of EC 53: An Episodically
Accreting Class I Young Stellar Object", arXiv:2004.05600.
https://arxiv.org/abs/2004.05600

Used for:
- radiative-transfer modelling context;
- outburst luminosity approximately 3.3 times quiescent luminosity;
- envelope heating interpretation.

## 4. Fabian et al. 2000
Fabian, D. et al. 2000, "Steps toward interstellar silicate mineralogy. V.
Thermal evolution of amorphous magnesium silicates and silica",
Astronomy & Astrophysics, 364, 282-292.

Used as laboratory basis for thermal evolution/crystallization of amorphous
magnesium silicates.

## 5. Public software named by Lee et al. 2026
- RADMC-3D: https://github.com/dullemond/radmc3d-2.0
- optool: https://github.com/cdominik/optool
- emcee: https://github.com/dfm/emcee
- JWST pipeline: https://github.com/spacetelescope/jwst

The software is NOT copied into this package.
