# Source Code Map

## Purpose
This file distinguishes externally authored/reused scientific software from project-specific integration code.

## 1. EC 53 authors' EPISODE repository
Repository: https://github.com/SNUSF/EPISODE

Source paper: Lee et al. (2026), Nature, DOI 10.1038/s41586-025-09939-3.

The repository states that it contains codes used for the EPISODE project, including:
- `make_opacity.py` for opacity generation;
- `Final_MCMC.ipynb` for silicate-profile baseline/MCMC fitting;
- EC 53 silicate optical-depth data;
- astrometry procedures.

This project does NOT silently copy those files. They are identified here as upstream source material and should be downloaded/used according to their repository terms.

## 2. EC 53 continuum/silicate-fitting repository
Repository: https://github.com/JY-Kim8502/JKAS_IRS_Continuum_fitting_with_Slicate

License stated by the repository: MIT.

The repository contains `Continuum_Fit_IRS_v1.py` and associated data/outputs for MIR continuum and silicate correction. It is relevant to the EC 53 paper's public code ecosystem, but it is not the crystallization solver itself.

## 3. RADMC-3D
Repository: https://github.com/dullemond/radmc3d-2.0

RADMC-3D is an established astrophysical radiative-transfer code. The EC 53 paper explicitly lists it among the public software used in the study.

This project does not vendor RADMC-3D source files. Use the upstream repository and its own distribution terms.

## 4. optool
Repository: https://github.com/cdominik/optool

optool is used for dust opacity calculations and is listed by the EC 53 paper. Its repository states that it is distributed under the MIT license and requests citation.

## 5. emcee
Repository: https://github.com/dfm/emcee

Used as an upstream MCMC package in the EC 53 analysis ecosystem. This project does not copy emcee source code; it is an external dependency when required.

## 6. JWST Calibration Pipeline
Repository: https://github.com/spacetelescope/jwst
Documentation: https://jwst-pipeline.readthedocs.io/en/latest/

The EC 53 paper reports reprocessing JWST MIRI data with JWST Calibration Pipeline v1.18.0.

## 7. Project-specific code
The following files in this ZIP are project-specific integration/implementation and MUST NOT be described as copied from the papers:
- `app.py`
- `src/model.py`
- `src/io.py`
- `src/plotting.py`
- `src/run_final.py`
- `scripts/check_provenance.py`
- `scripts/run_tests.py`
- `tests/test_model.py`

These files implement the interface, input validation, connection of T(t) to the published kinetic law, numerical checking, sensitivity experiments, and file handling.

## Bottom line
The source-backed parts are the scientific observational context, published kinetic parameters/equations, and identified upstream astrophysical software. The ZIP does not falsely label newly written integration code as copied source code.
