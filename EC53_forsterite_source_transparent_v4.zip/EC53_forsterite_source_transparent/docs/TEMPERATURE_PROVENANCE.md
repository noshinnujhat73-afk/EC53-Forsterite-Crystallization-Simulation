# Temperature provenance

STATUS: NOT YET FILLED.

This file must be completed before claiming an EC 53-specific temperature result.

Required fields:
- Source paper/model:
- Repository:
- Data DOI/archive:
- Model version/commit:
- Radial location or extraction region:
- Time interval:
- Temperature definition (midplane, surface, optically thin dust, etc.):
- Interpolation method:
- Any radiative-transfer assumptions:
- Units:
- File hash:

The package deliberately stops if no temperature history is provided.
