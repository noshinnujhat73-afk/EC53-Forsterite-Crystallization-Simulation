# Modifications and Source-Reuse Policy — Version 4

This package intentionally distinguishes upstream scientific software from project-specific integration.

## Reused / externally referenced
The project links to the public repositories and papers documented in `SOURCE_CODE_MAP.md` and `SOURCE_URLS.txt`. Their code is **not represented as our original work**.

## Project-specific code
The following components are written/adapted for this study:
- `src/model.py`: connects the published Arrhenius crystallization law to a supplied non-isothermal temperature history and performs RK45 integration plus independent quadrature validation.
- `src/multiburst.py`: repeats a supplied thermal history across multiple modelled bursts.
- `app.py`: Streamlit interface, validation, plotting and exports.

## Version 4 changes
1. Replaced the former trapezoidal validation with adaptive `scipy.integrate.quad`.
2. Restored multi-burst simulation capability.
3. Added stronger automated tests for numerical validation and multi-burst behavior.
4. Added final scientific-status documentation.
5. Sensitivity controls remain explicitly labelled as computational experiments, not observational constraints.
6. No synthetic EC 53 temperature history was inserted.
