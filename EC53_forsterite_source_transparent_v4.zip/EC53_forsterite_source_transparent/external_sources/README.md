# External Source Repositories

The project uses source-linked upstream scientific software rather than copying entire third-party repositories into this ZIP.

See `../docs/SOURCE_CODE_MAP.md` for the role of each source and `../docs/SOURCE_URLS.txt` for direct links.

The EC 53 Nature paper explicitly identifies EPISODE, the continuum/silicate-fitting repository, RADMC-3D, optool, emcee and the JWST pipeline as public code/software used in the study.
